-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le :  lun. 12 avr. 2021 à 09:49
-- Version du serveur :  8.0.18
-- Version de PHP :  7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `testatc`
--

-- --------------------------------------------------------

--
-- Structure de la table `manager_has_users`
--

DROP TABLE IF EXISTS `manager_has_users`;
CREATE TABLE IF NOT EXISTS `manager_has_users` (
  `manager_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `manager_id` (`manager_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `manager_has_users`
--

INSERT INTO `manager_has_users` (`manager_id`, `user_id`) VALUES
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 10),
(3, 8),
(3, 9),
(3, 10),
(3, 11),
(3, 4);

-- --------------------------------------------------------

--
-- Structure de la table `points`
--

DROP TABLE IF EXISTS `points`;
CREATE TABLE IF NOT EXISTS `points` (
  `point_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`point_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `points`
--

INSERT INTO `points` (`point_id`, `user_id`, `latitude`, `longitude`, `datetime`) VALUES
(1, 11, '43.610930', '3.876350', '2021-04-09 10:58:41'),
(2, 10, '43.610930', '3.876350', '2021-04-09 11:00:08'),
(3, 9, '43.610930', '3.876350', '2021-04-09 11:00:23'),
(4, 8, '43.610930', '3.876350', '2021-04-09 11:00:33'),
(5, 7, '43.610930', '3.876350', '2021-04-09 11:00:41'),
(6, 6, '43.610930', '3.876350', '2021-04-09 11:00:49'),
(7, 5, '43.610930', '3.876350', '2021-04-09 11:01:03'),
(8, 4, '43.610930', '3.876350', '2021-04-09 11:01:14'),
(9, 2, '43.610930', '3.876350', '2021-04-09 14:09:19'),
(10, 2, '43.610930', '3.876350', '2021-04-09 14:10:03'),
(11, 2, '43.610930', '3.876350', '2021-04-09 14:10:42'),
(12, 2, '43.610930', '3.876350', '2021-04-09 14:11:09'),
(13, 2, '43.610930', '3.876350', '2021-04-09 14:11:37'),
(14, 2, '43.610930', '3.876350', '2021-04-09 14:13:14'),
(15, 11, '43.610930', '3.876350', '2021-04-09 14:15:41'),
(16, 11, '43.610930', '3.876350', '2021-04-09 14:18:35'),
(17, 2, '43.610930', '3.876350', '2021-04-09 14:18:45'),
(18, 2, '43.610930', '3.876350', '2021-04-09 14:19:13'),
(19, 2, '43.610930', '3.876350', '2021-04-09 14:19:18'),
(20, 2, '43.610930', '3.876350', '2021-04-09 14:19:56'),
(21, 2, '43.610930', '3.876350', '2021-04-09 14:20:01'),
(22, 2, '43.610930', '3.876350', '2021-04-09 14:51:14'),
(23, 2, '43.610930', '3.876350', '2021-04-09 14:51:54'),
(24, 3, '43.610930', '3.876350', '2021-04-09 14:53:03'),
(25, 11, '43.610930', '3.876350', '2021-04-10 13:34:21'),
(26, 3, '43.610930', '3.876350', '2021-04-10 13:34:36'),
(27, 3, '43.610930', '3.876350', '2021-04-10 13:44:56'),
(28, 3, '43.610930', '3.876350', '2021-04-10 13:45:41'),
(29, 3, '43.610930', '3.876350', '2021-04-10 13:46:39'),
(30, 2, '43.610930', '3.876350', '2021-04-10 13:47:22'),
(31, 2, '43.610930', '3.876350', '2021-04-10 13:47:51'),
(32, 2, '43.610930', '3.876350', '2021-04-10 13:48:37'),
(33, 2, '43.610930', '3.876350', '2021-04-10 13:48:55'),
(34, 2, '43.610930', '3.876350', '2021-04-10 13:49:54'),
(35, 2, '43.610930', '3.876350', '2021-04-10 13:50:11'),
(36, 2, '43.610930', '3.876350', '2021-04-10 14:07:10'),
(37, 2, '43.610930', '3.876350', '2021-04-10 14:07:26'),
(38, 10, '43.610930', '3.876350', '2021-04-10 14:07:37'),
(39, 1, '43.610930', '3.876350', '2021-04-10 14:07:52'),
(40, 1, '43.610930', '3.876350', '2021-04-10 14:15:23'),
(41, 1, '43.610930', '3.876350', '2021-04-10 14:16:11'),
(42, 1, '43.610930', '3.876350', '2021-04-10 14:16:14'),
(43, 1, '43.610930', '3.876350', '2021-04-10 14:16:21'),
(44, 1, '43.610930', '3.876350', '2021-04-10 14:17:06'),
(45, 1, '43.610930', '3.876350', '2021-04-10 14:19:41'),
(46, 1, '43.610930', '3.876350', '2021-04-10 14:20:32'),
(47, 1, '43.610930', '3.876350', '2021-04-10 14:45:32'),
(48, 1, '43.610930', '3.876350', '2021-04-10 14:45:44'),
(49, 1, '43.610930', '3.876350', '2021-04-10 14:47:20'),
(50, 2, '43.610930', '3.876350', '2021-04-10 14:47:44'),
(51, 3, '43.610930', '3.876350', '2021-04-10 14:47:57'),
(52, 2, '43.610930', '3.876350', '2021-04-10 14:51:59'),
(53, 2, '43.610930', '3.876350', '2021-04-10 14:52:50'),
(54, 2, '43.610930', '3.876350', '2021-04-10 14:53:11'),
(55, 4, '43.610930', '3.876350', '2021-04-10 14:53:57'),
(56, 4, '43.610930', '3.876350', '2021-04-10 14:54:10'),
(57, 1, '0.000000', '0.000000', '2021-04-10 15:10:17'),
(58, 1, '0.000000', '0.000000', '2021-04-10 15:11:02'),
(59, 2, '43.610930', '3.876350', '2021-04-11 15:48:38'),
(60, 1, '43.610930', '3.876350', '2021-04-11 15:49:04'),
(61, 3, '43.610930', '3.876350', '2021-04-11 15:49:58');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(20) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`role_id`, `rolename`) VALUES
(1, 'admin'),
(2, 'manager'),
(3, 'user');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role_id`) VALUES
(1, 'admin', '$2y$10$9cntgbXfLXn9XxN3RAosn.tuUe4LnyR30EdkidLFe/dNLXa6RO0Jy', 1),
(2, 'marc', '$2y$10$vBVVY6b59ogOXyn12DG1WevXNxIcAQ.ncRlg0ieTBKu9RZMKW4FXK', 2),
(3, 'michelle', '$2y$10$llt2zpuMdjjpJQBIRyj6GO3k97qO8LBZVRj2yzhLVxfHmwT1KRNE6', 2),
(4, 'alain', '$2y$10$HfwiPXjlwOeeXhhbEZtBz.5RbiGAIrS3nwCaIwPkx/GDLt3XWHDjW', 3),
(5, 'bernard', '$2y$10$s79J7ENpV2LJ9AWhiJkyn.yGsHYDqscO9KaxV5.SXN0nhoOTrfUCe', 3),
(6, 'chris', '$2y$10$MKeCI8daeintSVmJLTESfeV.h/VPUazb1nr01huBZkMWc4gDwZfhq', 3),
(7, 'daniel', '$2y$10$HTyMrDxDeS/ngz.X6NiefOxtBzsnvQiWYj/ylpeBptQiQiO19046.', 3),
(8, 'Anatole', '$2y$10$STWOwc6et1vM30fOQVdhCelXLTT5dUkNFuSJXB9/E8Ep1wolRULlO', 3),
(9, 'Bruno', '$2y$10$QtfGm9MyiHMc3ujiY8Dei.9yEbapA7tot7U1XqAbVbg2hEJO8px6.', 3),
(10, 'Caroline', '$2y$10$PUtlJpm0bjJfNaHtGLVYgeHDDX9LHQuei1wZ7/z4jPycTM4laYmZW', 3),
(11, 'Denise', '$2y$10$3S6CKi2RQavalueVpHXyPuH0GOsDp6M8d2V2K3.eK4x2J1M9FRRFK', 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
